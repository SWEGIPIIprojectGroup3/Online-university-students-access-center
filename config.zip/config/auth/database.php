<?php
$dbServername="localhost:3306";
$username="root";
$password="";
$dbName="online students access center";
$conn=mysqli_connect($dbServername,$username,$password,$dbName) or die("couldn't connect to database");
?>